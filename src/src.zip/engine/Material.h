#pragma once
class Material
{
public:
	Material();
	virtual ~Material();
};

