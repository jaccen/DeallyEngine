#pragma once
class Reanderable
{
public:
	Reanderable();
	virtual ~Reanderable();
};

