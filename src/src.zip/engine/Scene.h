#pragma once
class Scene
{
public:

	Scene()
	{
	}

	virtual ~Scene()
	{
	}
};

