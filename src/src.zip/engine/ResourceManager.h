#pragma once
class ResourceManager
{
public:
	ResourceManager();
	~ResourceManager();
};

