#pragma once
class Texture
{
public:
	Texture();
	virtual ~Texture();
};

