#pragma once
class Application
{
public:
	Application();
	virtual ~Application();

private:
};

