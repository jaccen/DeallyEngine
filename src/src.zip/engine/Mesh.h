#pragma once
class Mesh
{
public:
	Mesh();
	virtual ~Mesh();
};

