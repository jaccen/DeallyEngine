#pragma once
class Shader
{
public:
	Shader();
	virtual ~Shader();
};

