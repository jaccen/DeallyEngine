#pragma once
class Node
{
public:
	Node();
	virtual ~Node();
};

