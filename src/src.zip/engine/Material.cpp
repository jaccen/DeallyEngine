#include "Material.h"
Material::Material()
{
}


Material::~Material()
{
}
