Zookeeper based name resolver: WIP
